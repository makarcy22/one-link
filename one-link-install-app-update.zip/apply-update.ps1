# One Link v2 update. Run from your PROJECT ROOT after unzipping the update next to it.
# What it does: copies the new and changed files over your project, after making a backup
# of every file it is about to replace. It never opens or changes any .env file and never deletes anything.
#
# Usage (PowerShell):   .\apply-update.ps1 -Update "C:\path\to\one-link-v2-update"
param([Parameter(Mandatory=$true)][string]$Update)

$ErrorActionPreference = "Stop"
$root = (Get-Location).Path
if (-not (Test-Path (Join-Path $root "package.json")) -or -not (Test-Path (Join-Path $root "apps"))) {
  Write-Host "Run this from your One Link project root (the folder that contains apps and packages)." -ForegroundColor Red; exit 1
}
if (-not (Test-Path $Update)) { Write-Host "Update folder not found: $Update" -ForegroundColor Red; exit 1 }

$files = Get-ChildItem -Path $Update -Recurse -File | Where-Object { $_.Name -notlike ".env*" -and $_.Name -ne "apply-update.ps1" }
$updRoot = (Resolve-Path $Update).Path
$replace = @(); $add = @()
foreach ($f in $files) {
  $rel = $f.FullName.Substring($updRoot.Length).TrimStart('\','/')
  $dest = Join-Path $root $rel
  if (Test-Path $dest) { $replace += $rel } else { $add += $rel }
}
Write-Host ""
Write-Host "New files:      $($add.Count)"
Write-Host "Files replaced: $($replace.Count)  (each is backed up first)"
$ans = Read-Host "Type YES to continue"
if ($ans -ne "YES") { Write-Host "Nothing was changed."; exit 0 }

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $root "backup-before-v2-$stamp"
foreach ($rel in $replace) {
  $src = Join-Path $root $rel
  $bk = Join-Path $backup $rel
  New-Item -ItemType Directory -Force -Path (Split-Path $bk) | Out-Null
  Copy-Item $src $bk
}
foreach ($rel in ($add + $replace)) {
  $dest = Join-Path $root $rel
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Copy-Item (Join-Path $updRoot $rel) $dest -Force
}
Write-Host ""
Write-Host "Done. Backup of replaced files: $backup" -ForegroundColor Green
Write-Host "Next: npm install, then run apps/api/migrations/007_v2_features.sql, then read docs/v2-update.md"
